var n;


try {
    var ffffff = 1;

}
catch(err) {
  alert(`возникла ошибка! ${err} `); // (3) <--

}

finally {
    alert(`Выполнено!`);

}

