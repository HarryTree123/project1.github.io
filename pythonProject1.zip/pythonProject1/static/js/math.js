function showSum( numa, numb ){
   return = numa + numb;

}

function showMin( numa, numb ){
    return nums = numa - numb;

}

function showMul( numa, numb ){
    return nums = numa * numb;

}

function showDen( numa, numb ){
    return nums = numa / numb;

}

